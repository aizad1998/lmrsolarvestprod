@extends("layouts.app")
		
		@section("wrapper")
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">

				<div style="height: 600px;">
				    
					<h2>This is blank page </h2>
				
				</div>

			</div>
		</div>
		<!--end page wrapper -->
		@endsection
	