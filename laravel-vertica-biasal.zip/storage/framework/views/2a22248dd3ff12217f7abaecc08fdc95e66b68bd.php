
		
		<?php $__env->startSection("wrapper"); ?>
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">

				<div style="height: 600px;">
				    
					<h2>This is blank page </h2>
				
				</div>

			</div>
		</div>
		<!--end page wrapper -->
		<?php $__env->stopSection(); ?>
	
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creatantech/public_html/demos/codervent/laravel-vertical/resources/views/error-blank-page.blade.php ENDPATH**/ ?>