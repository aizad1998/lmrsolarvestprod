


<?php $__env->startSection('title', 'Its my title'); ?>

<?php $__env->startSection('sidebar'); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\envato\codervent\laravel\resources\views/layouts/child.blade.php ENDPATH**/ ?>