
<html>
    <head>
        <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body>
        <?php echo $__env->yieldContent("myhead"); ?>
        <?php $__env->startSection('sidebar'); ?>
           
        <?php echo $__env->yieldSection(); ?>

        <?php echo $__env->yieldContent("mysection1"); ?>
        

        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
            Hello
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\envato\codervent\laravel\resources\views/test/app.blade.php ENDPATH**/ ?>