<br>1<br>
<?php echo $__env->make("layouts_test.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>2<br>

<br>3<br>

<br>4<br>

<br>END<br>
<?php /**PATH C:\xampp\htdocs\envato\codervent\laravel\resources\views/layouts_test/app.blade.php ENDPATH**/ ?>