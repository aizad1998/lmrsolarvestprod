<div class="nav-container">
			This is Nav
		</div><?php /**PATH C:\xampp\htdocs\envato\codervent\laravel\resources\views/layouts_test/nav.blade.php ENDPATH**/ ?>