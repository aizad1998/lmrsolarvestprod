<header>
			This is Header
		</header><?php /**PATH C:\xampp\htdocs\envato\codervent\laravel\resources\views/layouts_test/header.blade.php ENDPATH**/ ?>